# Задание №5. SQL-запросы

1. Простой SELECT

```
SELECT * FROM employees;
```
SELECT. Команда для извлечения данных из БД. Извлечем все данные из таблицы `employees`.


2. Простое условие

```
SELECT product_id, product_name
FROM inventory
WHERE product_id = 101;
```
Запрос SELECT. Извлекает столбцы `product_id`, `product_name`. Из таблицы `inventory`. `WHERE` позволяет извлекать, обновлять или удалять именно те данные,  в которых значение `product_id` равен 101.

3. Двойное условие.

```
SELECT product_name, price
FROM products
WHERE category = 'Clothing' OR price < 50;
```

Запрос SELECT. Извлекает столбцы `product_name`, `price`. Из таблицы `products`. `WHERE` позволяет извлекать, обновлять или удалять именно те данные,  в которых значение `category` равно `Clothing`, `OR`(используются для фильтрации записей на основе более чем одного условия) либо `price` меньше 50.

4. Агрегирование данных

```
SELECT department, AVG(salary) AS avg_salary
FROM employees
GROUP BY department
HAVING avg_salary > 50000;
```
Запрос SELECT. Групирует(GROUP) данные из таблицы `employees`, столбца `salary`, по столбцу `department`. Затем AVG(вычисляет среднее значение на диапазоне значений столбца таблицы) `salary`, затем фильтрует результаты `HAVING`(позволяет выполнить фильтрацию групп, то есть определяет, какие группы будут включены в выходной результат), у которых `avg_salary` больше 50000.

5. Сортировка

```
SELECT product_name, price
FROM products
WHERE category = `Electronics`
ORDER BY price DESC;
```

Запрос SELECT. Извлекает столбцы `product_name`, `price`, из таблицы `products`, `WHERE` позволяет извлекать, обновлять или удалять именно те данные,  в которых значение столбца `category`, которое равно `Electronics`. Затем `DESC` (сортирует от высоких значений к низким), по столбцу `price`.