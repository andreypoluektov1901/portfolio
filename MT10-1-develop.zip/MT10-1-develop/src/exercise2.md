# Задание №2. Локальное хранилище

1. Какое название имеет ключ?
* cartItem_2

| key | value |
|----------|----------|
| cartItem_2   | {"keys":["1725010014823"],"data":{"1725010014823":{"id":1725010014823,"cartId":-1,"objId":"wL2x01jrkR8QWbx-ebNAFw","creationTime":1725010014823,"count":1,"shopId":431782,"marketSku":"101884456907","productId":665306170,"hid":91122,"name":"Игровая приставка Sony PlayStation 5 825 ГБ SSD, белый","price":{"value":73287,"currency":"RUR"},"fee":"OTNDnItfwRPavIQicanoEvpmihc97DdRvseArPLbK43-6EV10_L1NV6ZYSHFMqbRjDcLfM6bOUWHRQvA_7L3nbRf6Qls5cNnjjbQIMaB9A8wIBmUF6CHhKsy1U_GSkO-Sg6HZEBYvNSP2pikPltHNBZo8urIkq7H","cartFee":"OTNDnItfwRPavIQicanoEvpmihc97DdRvseArPLbK43-6EV10_L1NV6ZYSHFMqbRjDcLfM6bOUWHRQvA_7L3nbRf6Qls5cNnjjbQIMaB9A8wIBmUF6CHhKsy1U_GSkO-Sg6HZEBYvNSP2pikPltHNBZo8urIkq7H","feeShow":"OTNDnItfwRPavIQicanoEvpmihc97DdRvseArPLbK43-6EV10_L1NV6ZYSHFMqbRjDcLfM6bOUWHRQvA_7L3nbRf6Qls5cNnjjbQIMaB9A8wIBmUF6CHhKsy1U_GSkO-Sg6HZEBYvNSP2pikPltHNBZo8urIkq7H","showPlaceId":"OTNDnItfwRPavIQicanoEvpmihc97DdRvseArPLbK43-6EV10_L1NV6ZYSHFMqbRjDcLfM6bOUWHRQvA_7L3nbRf6Qls5cNnjjbQIMaB9A8wIBmUF6CHhKsy1U_GSkO-Sg6HZEBYvNSP2pikPltHNBZo8urIkq7H","slug":"igrovaia-pristavka-sony-playstation-5-825-gb-ssd-belyi","isExpired":false,"promos":[{"promoType":"discount-by-payment-type","promoKey":"6Y84Q8_doRrHsTQXGDkSRQ"},{"promoType":"parent-promo","promoKey":"cf_sp_119276"},{"promoType":"parent-promo","promoKey":""},{"promoType":"direct-discount","promoKey":"bZSjgEZh8V0jbBmIsjOkjg"},{"promoType":"discount-by-payment-type","promoKey":"fZ3XLaWtLFCVyd6AGdo2aA"}],"isPrimaryInBundle":false,"label":"06b9oyh2ffg8","pricedropPromoEnabled":false,"features":[],"isDirectShopInShop":false,"rgb":"WHITE","pictures":[{"entity":"picture","original":{"namespace":"mpic","groupId":4080439,"key":"img_id3396893556724706605.jpeg"}}],"businessId":93914410}},"meta":{"1725010014823":{"timestamp":1725010014463}},"timestamp":1725010014463,"version":"2024.08.35.0.t2529165763"}  |


2. Какой объект хранит в себе поле «data» в значении ключа (полностью вставьте его значение)?
```
{
  "id": 1725010014823,
  "cartId": -1,
  "objId": "wL2x01jrkR8QWbx-ebNAFw",
  "creationTime": 1725010014823,
  "count": 1,
  "shopId": 431782,
  "marketSku": "101884456907",
  "productId": 665306170,
  "hid": 91122,
  "name": "Игровая приставка Sony PlayStation 5 825 ГБ SSD, белый",
  "price": {
    "value": 73287,
    "currency": "RUR"
  },
  "fee": "OTNDnItfwRPavIQicanoEvpmihc97DdRvseArPLbK43-6EV10_L1NV6ZYSHFMqbRjDcLfM6bOUWHRQvA_7L3nbRf6Qls5cNnjjbQIMaB9A8wIBmUF6CHhKsy1U_GSkO-Sg6HZEBYvNSP2pikPltHNBZo8urIkq7H",
  "cartFee": "OTNDnItfwRPavIQicanoEvpmihc97DdRvseArPLbK43-6EV10_L1NV6ZYSHFMqbRjDcLfM6bOUWHRQvA_7L3nbRf6Qls5cNnjjbQIMaB9A8wIBmUF6CHhKsy1U_GSkO-Sg6HZEBYvNSP2pikPltHNBZo8urIkq7H",
  "feeShow": "OTNDnItfwRPavIQicanoEvpmihc97DdRvseArPLbK43-6EV10_L1NV6ZYSHFMqbRjDcLfM6bOUWHRQvA_7L3nbRf6Qls5cNnjjbQIMaB9A8wIBmUF6CHhKsy1U_GSkO-Sg6HZEBYvNSP2pikPltHNBZo8urIkq7H",
  "showPlaceId": "OTNDnItfwRPavIQicanoEvpmihc97DdRvseArPLbK43-6EV10_L1NV6ZYSHFMqbRjDcLfM6bOUWHRQvA_7L3nbRf6Qls5cNnjjbQIMaB9A8wIBmUF6CHhKsy1U_GSkO-Sg6HZEBYvNSP2pikPltHNBZo8urIkq7H",
  "slug": "igrovaia-pristavka-sony-playstation-5-825-gb-ssd-belyi",
  "isExpired": false,
  "promos": [
    {
      "promoType": "discount-by-payment-type",
      "promoKey": "6Y84Q8_doRrHsTQXGDkSRQ"
    },
    {
      "promoType": "parent-promo",
      "promoKey": "cf_sp_119276"
    },
    {
      "promoType": "parent-promo",
      "promoKey": ""
    },
    {
      "promoType": "direct-discount",
      "promoKey": "bZSjgEZh8V0jbBmIsjOkjg"
    },
    {
      "promoType": "discount-by-payment-type",
      "promoKey": "fZ3XLaWtLFCVyd6AGdo2aA"
    }
  ],
  "isPrimaryInBundle": false,
  "label": "06b9oyh2ffg8",
  "pricedropPromoEnabled": false,
  "features": [],
  "isDirectShopInShop": false,
  "rgb": "WHITE",
  "pictures": [
    {
      "entity": "picture",
      "original": {
        "namespace": "mpic",
        "groupId": 4080439,
        "key": "img_id3396893556724706605.jpeg"
      }
    }
  ],
  "businessId": 93914410
}
```
3. Какое поле хранит в себе название товара, добавленного в корзину?
* поле name
```
"name": "Игровая приставка Sony PlayStation 5 825 ГБ SSD, белый",
```

4. Какое поле хранит в себе стоимость товара, добавленного в корзину?
* поле value в обьекте price.
```
"price": {
    "value": 73287,
    "currency": "RUR"
```
5. Как узнать количество товара, которое было добавлено в корзину?
* Посмотреть поле count, оно отображает колличество выбранного товара одного типа.
```
 "count": 1,
```