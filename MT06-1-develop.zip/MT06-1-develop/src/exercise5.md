
## 1. Activities
#### 1.
1. HTTP-метод; GET
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Activities
3. Заголовки запроса;
```'
{
"accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
    "id": 1,
    "title": "Activity 1",
    "dueDate": "2024-07-28T12:41:33.0107931+00:00",
    "completed": false
  },
  {
    "id": 2,
    "title": "Activity 2",
    "dueDate": "2024-07-28T13:41:33.010796+00:00",
    "completed": true
  },
  {
    "id": 3,
    "title": "Activity 3",
    "dueDate": "2024-07-28T14:41:33.0107963+00:00",
    "completed": false
  },
  ...
```
#### 2. 
1. HTTP-метод; POST
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Activities
3. Заголовки запроса;
```
{
"accept: text/plain; v=1.0" 
"Content-Type: application/json; v=1.0" 
}
 ```
4. Тело запроса (при наличии);
```
{
  "id": 0,
  "title": "string",
  "dueDate": "2024-07-27T17:30:36.742Z",
  "completed": true
}
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 0,
  "title": "string",
  "dueDate": "2024-07-27T17:30:36.742Z",
  "completed": true
}
```
#### 3.
1. HTTP-метод; POST
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Activities
3. Заголовки запроса;
```
{
"accept: text/plain; v=1.0"
"Content-Type: application/json
}
```
4. Тело запроса (при наличии);
```
{
  "id": @,
  "title": "string",
  "dueDate": "2024-07-28T11:46:45.156Z",
  "completed": true
}
```
5. Статус-код ответа; 400
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-e66672b626748248920971c57b42f001-b2bc24745a837541-00",
  "errors": {
    "$.id": [
      "'@' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 8."
    ]
  }
}
```
### 4.
1. HTTP-метод; GET {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Activities/15
3. Заголовки запроса;
```
{
"accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 15,
  "title": "Activity 15",
  "dueDate": "2024-07-29T03:02:48.0915602+00:00",
  "completed": false
}
```
### 5.
1. HTTP-метод; GET {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Activities/0
3. Заголовки запроса;
```
{
"accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 404
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
  "title": "Not Found",
  "status": 404,
  "traceId": "00-a629c6bacf5bef48a4b3c87a8340b4ac-0622303f78c34147-00"
}
```
### 6.
1. HTTP-метод;  PUT {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Activities/1
3. Заголовки запроса;
```
{
"accept: text/plain; v=1.0"
"Content-Type: application/json; v=1.0"
}
```
4. Тело запроса (при наличии);
```
{
  "id": 40,
  "title": "string",
  "dueDate": "2024-07-28T12:10:33.048Z",
  "completed": true
}
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 40,
  "title": "string",
  "dueDate": "2024-07-28T12:10:33.048Z",
  "completed": true
}
```
### 7.
1. HTTP-метод; PUT{id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Activities/1
3. Заголовки запроса;
```
{
"accept: text/plain; v=1.0"
"Content-Type: application/json; v=1.0"
}
```
4. Тело запроса (при наличии);
```
{
  "id": @,
  "title": "string",
  "dueDate": "2024-07-28T12:10:33.048Z",
  "completed": true
}
```
5. Статус-код ответа; 400
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-64d0aaebacfb084babfc41387fff9efb-ba7e0ee131b24b47-00",
  "errors": {
    "$.id": [
      "'@' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 8."
    ]
  }
}
```
### 8.
1. HTTP-метод; DELETE {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Activities/1
3. Заголовки запроса;
```
{
"accept: */*"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
```
## 2. Authors
### 1. 
1. HTTP-метод; GET
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Authors
3. Заголовки запроса; 
```
{
  "accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
    "id": 1,
    "idBook": 1,
    "firstName": "First Name 1",
    "lastName": "Last Name 1"
  },
  {
    "id": 2,
    "idBook": 1,
    "firstName": "First Name 2",
    "lastName": "Last Name 2"
  },
  {
    "id": 3,
    "idBook": 1,
    "firstName": "First Name 3",
    "lastName": "Last Name 3"  
  } 
  ...  
```

### 2. 
1. HTTP-метод; POST
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Authors
3. Заголовки запроса;
```
{
"accept: text/plain; v=1.0"
"Content-Type: application/json; v=1.0"
}
```
4. Тело запроса (при наличии);
```
{
  "id": 0,
  "idBook": 0,
  "firstName": "string",
  "lastName": "string"
}
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 0,
  "idBook": 0,
  "firstName": "string",
  "lastName": "string"
}
```
### 3. 
1. HTTP-метод; POST
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Authors
3. Заголовки запроса;
```
"accept: text/plain; v=1.0"
 "Content-Type: application/json; v=1.0"
```
4. Тело запроса (при наличии);
```
{
  "id": @,
  "idBook": 0,
  "firstName": "string",
  "lastName": "string"
}
```
5. Статус-код ответа; 400
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-63c3828d6175b24eb049dfd52cb098b9-64daf06beed1c043-00",
  "errors": {
    "$.id": [
      "'@' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 8."
    ]
  }
}
```
### 4. 
1. HTTP-метод;  GET {idBook}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Authors/authors/books/1
3. Заголовки запроса;
```
{
"accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
[
  {
    "id": 1,
    "idBook": 1,
    "firstName": "First Name 1",
    "lastName": "Last Name 1"
  },
  {
    "id": 2,
    "idBook": 1,
    "firstName": "First Name 2",
    "lastName": "Last Name 2"
  },
  {
    "id": 3,
    "idBook": 1,
    "firstName": "First Name 3",
    "lastName": "Last Name 3"
  },
  {
    "id": 4,
    "idBook": 1,
    "firstName": "First Name 4",
    "lastName": "Last Name 4"
  }
  ...
]
```
### 5.  
1. HTTP-метод; GET {idBook}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Authors/authors/books/11111111111
3. Заголовки запроса;
```
{
 "accept: text/plain; v=1.0"
}
 ```
4. Тело запроса (при наличии);
5. Статус-код ответа; 400
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-74e0c7f9d132764d8537dd7c4fcfc043-ce9d3386d02f544f-00",
  "errors": {
    "idBook": [
      "The value '11111111111' is not valid."
    ]
  }
}
```
### 6. 
1. HTTP-метод; GET {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Authors/1
3. Заголовки запроса;
```
{
"accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии);
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 1,
  "idBook": 1,
  "firstName": "First Name 1",
  "lastName": "Last Name 1"
}
```
### 7. 
1. HTTP-метод; GET{id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Authors/0
3. Заголовки запроса; 
```
{
"accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии); 
5. Статус-код ответа; 404
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
  "title": "Not Found",
  "status": 404,
  "traceId": "00-39a583ac92727b44b8950fed9e62d404-d0836e800989e443-00"
}
```
### 8. 
1. HTTP-метод; PUT {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Authors/1
3. Заголовки запроса;
```
{
"accept: text/plain; v=1.0"
 "Content-Type: application/json; v=1.0"
 }
 ```
4. Тело запроса (при наличии);
```
{
  "id": 0,
  "idBook": 0,
  "firstName": "string",
  "lastName": "string"
}
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 0,
  "idBook": 0,
  "firstName": "string",
  "lastName": "string"
}
```
### 9. 
1. HTTP-метод; PUT {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Authors/1
3. Заголовки запроса;
```
{
"accept: text/plain; v=1.0"
"Content-Type: application/json; v=1.0"
}
```

4. Тело запроса (при наличии); 
```
{
  "id": @,
  "idBook": 0,
  "firstName": "string",
  "lastName": "string"
}
```
5. Статус-код ответа; 400
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-0bbb525d887d384ea805d6681c19d77d-50ad87ae802b5443-00",
  "errors": {
    "$.id": [
      "'@' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 8."
    ]
  }
}
```
### 10. 
1. HTTP-метод; DELETE{id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Authors/1
3. Заголовки запроса;
```
{
  "accept: */*"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
```
## 3. Books
### 1. 
1. HTTP-метод; GET
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Books
3. Заголовки запроса;
```
{
  "accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
  {
    "id": 1,
    "title": "Book 1",
    "description": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
    "pageCount": 100,
    "excerpt": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
    "publishDate": "2024-07-27T14:26:33.3234378+00:00"
  },
  {
    "id": 2,
    "title": "Book 2",
    "description": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
    "pageCount": 200,
    "excerpt": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
    "publishDate": "2024-07-26T14:26:33.3234533+00:00"
  },
  {
    "id": 3,
    "title": "Book 3",
    "description": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
    "pageCount": 300,
    "excerpt": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
    "publishDate": "2024-07-25T14:26:33.3234653+00:00"
  }
  ...
```
### 2. 
1. HTTP-метод; POST
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Books
3. Заголовки запроса;
```
{
"accept: */*"
 "Content-Type: application/json; v=1.0"
}
```
4. Тело запроса (при наличии);
```
{
  "id": 0,
  "title": "string",
  "description": "string",
  "pageCount": 0,
  "excerpt": "string",
  "publishDate": "2024-07-28T15:10:52.207Z"
}
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 0,
  "title": "string",
  "description": "string",
  "pageCount": 0,
  "excerpt": "string",
  "publishDate": "2024-07-28T15:10:52.207Z"
}
```
### 3. 
1. HTTP-метод; POST
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Books
3. Заголовки запроса;
```
"accept: */*"
"Content-Type: application/json; v=1.0"
```
4. Тело запроса (при наличии);
```
{
  "id": @,
  "title": "string",
  "description": "string",
  "pageCount": 0,
  "excerpt": "string",
  "publishDate": "2024-07-28T15:10:52.207Z"
}
```
5. Статус-код ответа; 400
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-ab5552b12db5d14eade945fb11804bc5-3a67b29da5009e4f-00",
  "errors": {
    "$.id": [
      "'@' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 8."
    ]
  }
```
### 4. 
1. HTTP-метод; GET {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Books/1
3. Заголовки запроса;
```
{
"accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 1,
  "title": "Book 1",
  "description": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
  "pageCount": 100,
  "excerpt": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
  "publishDate": "2024-07-27T15:17:48.1527017+00:00"
}
```
### 5. 
1. HTTP-метод; GET {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Books/0
3. Заголовки запроса;
```
{
 "accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии);
5. Статус-код ответа; 404
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
  "title": "Not Found",
  "status": 404,
  "traceId": "00-b887206d562cac4bb83f4b86c93cd414-fd2ab83f6ccee54e-00"
}
```
### 6. 
1. HTTP-метод; PUT {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Books/1
3. Заголовки запроса;
```
{ 
"accept: */*"
 "Content-Type: application/json; v=1.0"
 }
```
4. Тело запроса (при наличии);
```
{
  "id": @,
  "title": "string",
  "description": "string",
  "pageCount": 0,
  "excerpt": "string",
  "publishDate": "2024-07-28T15:24:28.193Z"
}
```
5. Статус-код ответа; 400
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-5f809d9ce5da6e419153994e2ec55267-6dc84114a8f6fe46-00",
  "errors": {
    "$.id": [
      "'@' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 8."
    ]
  }
}
```
### 7. 
1. HTTP-метод; PUT {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Books/1
3. Заголовки запроса;
```
{
  "accept: */*"
  "Content-Type: application/json; v=1.0"
}
```
4. Тело запроса (при наличии);
```
{
  "id": 1,
  "title": "string",
  "description": "string",
  "pageCount": 0,
  "excerpt": "string",
  "publishDate": "2024-07-28T15:24:28.193Z"
}
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 1,
  "title": "string",
  "description": "string",
  "pageCount": 0,
  "excerpt": "string",
  "publishDate": "2024-07-28T15:24:28.193Z"
}
```
### 8. 
1. HTTP-метод; DELETE {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Books/1
3. Заголовки запроса; 
```
"accept: */*"
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
```
## 4. CoverPhotos
### 1. 
1. HTTP-метод; GET
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos
3. Заголовки запроса; 
```
{
  "accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
    "id": 1,
    "idBook": 1,
    "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 1&w=250&h=350"
  },
  {
    "id": 2,
    "idBook": 2,
    "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 2&w=250&h=350"
  },
  {
    "id": 3,
    "idBook": 3,
    "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 3&w=250&h=350"
  },
  ...
```
### 2. 
1. HTTP-метод; POST
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos
3. Заголовки запроса; 
```
{
  "accept: text/plain; v=1.0"
  "Content-Type: application/json; v=1.0"
}
```
4. Тело запроса (при наличии);
```
{
  "id": 0,
  "idBook": 0,
  "url": "string"
}
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 0,
  "idBook": 0,
  "url": "string"
}
```
### 3. 
1. HTTP-метод; POST
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos
3. Заголовки запроса;
```
{
  "accept: text/plain; v=1.0"
  "Content-Type: application/json; v=1.0"
}
```
4. Тело запроса (при наличии);
```
{
  "id": @,
  "idBook": 0,
  "url": "string"
}
```
5. Статус-код ответа; 400
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-9b6b8050d9f14e41be44759d4b2d443b-e98d0e25fa049c4d-00",
  "errors": {
    "$.id": [
      "'@' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 8."
    ]
  }
}
```
### 4. 
1. HTTP-метод; GET {idNook}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/books/covers/1
3. Заголовки запроса;
```
{
   "accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
[
  {
    "id": 1,
    "idBook": 1,
    "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 1&w=250&h=350"
  }
]
```
### 5. 
1. HTTP-метод; GET {idBook}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/books/covers/11111111111
3. Заголовки запроса;
```
"accept: text/plain; v=1.0"
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 400
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-455ac240c1f9e749a96e6749ee887585-d53379314e4a3f45-00",
  "errors": {
    "idBook": [
      "The value '11111111111' is not valid."
    ]
  }
}
```
### 6. 
1. HTTP-метод; GET {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/1
3. Заголовки запроса;
```
{
"accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 1,
  "idBook": 1,
  "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 1&w=250&h=350"
}
```
### 7. 
1. HTTP-метод; GET{id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/0
3. Заголовки запроса;
```
{
  "accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 404
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
  "title": "Not Found",
  "status": 404,
  "traceId": "00-414abb3c3a20d440826aeee2f655bafe-9caf0c352e4ea34f-00"
}
```
### 8. 
1. HTTP-метод; PUT {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/1
3. Заголовки запроса;
```
{"accept: text/plain; v=1.0"
"Content-Type: application/json; v=1.0"}
```
4. Тело запроса (при наличии);
{
  "id": 0,
  "idBook": 0,
  "url": "string"
}
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 0,
  "idBook": 0,
  "url": "string"
}
```
### 9. 
1. HTTP-метод; PUT {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/1
3. Заголовки запроса;
```
{
  "accept: text/plain; v=1.0"
  "Content-Type: application/json; v=1.0"
}
```
4. Тело запроса (при наличии);
```
{
  "id": @,
  "idBook": 0,
  "url": "string"
}
```
5. Статус-код ответа; 400
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-5761a7c05752e942a3caf804528248a4-151046183738804f-00",
  "errors": {
    "$.id": [
      "'@' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 8."
    ]
  }
}
```
### 10. 
1. HTTP-метод; DELETE {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/1
3. Заголовки запроса;
```
{
  "accept: */*"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
```
## 5. Users
### 1. 
1. HTTP-метод; GET
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Users
3. Заголовки запроса; 
```
{
  "accept: text/plain; v=1.0"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
    "id": 1,
    "userName": "User 1",
    "password": "Password1"
  },
  {
    "id": 2,
    "userName": "User 2",
    "password": "Password2"
  },
  {
    "id": 3,
    "userName": "User 3",
    "password": "Password3"
}
...
```
### 2. 
1. HTTP-метод; POST
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Users
3. Заголовки запроса;
```
{
  "accept: */*"
  "Content-Type: application/json; v=1.0"
}
```
4. Тело запроса (при наличии);
```
{
  "id": 0,
  "userName": "string",
  "password": "string"
}
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 0,
  "userName": "string",
  "password": "string"
}
```
### 3. 
1. HTTP-метод; POST
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Users
3. Заголовки запроса;
```
{
  "accept: */*"
  "Content-Type: application/json; v=1.0"
}
```
4. Тело запроса (при наличии);
```
{
  "id": @,
  "userName": "string",
  "password": "string"
}
```
5. Статус-код ответа; 400
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-17e13e72ce0ca04fa48691b1df0f53ce-c781d99c025ce24c-00",
  "errors": {
    "$.id": [
      "'@' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 8."
    ]
  }
}
```
### 4. 
1. HTTP-метод; GET {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Users/1
3. Заголовки запроса;
```
{
   "accept: */*"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 1,
  "userName": "User 1",
  "password": "Password1"
}
```
### 5. 
1. HTTP-метод; GET {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Users/0
3. Заголовки запроса; 
```
{
  "accept: */*"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 404
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
  "title": "Not Found",
  "status": 404,
  "traceId": "00-4c0cc633c2b4e14b9271a7b80c9b85d6-98b609c6cfbeb94d-00"
}
```
### 6. 
1. HTTP-метод; PUT {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Users/1
3. Заголовки запроса;
```
{
  "accept: */*"
  "Content-Type: application/json; v=1.0"
}
```
4. Тело запроса (при наличии);
```
{
  "id": 0,
  "userName": "string",
  "password": "string"
}
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "id": 0,
  "userName": "string",
  "password": "string"
}
```
### 7. 
1. HTTP-метод; PUT {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Users/1
3. Заголовки запроса;
```
{
  "accept: */*"
  "Content-Type: application/json; v=1.0" -d
}
```
4. Тело запроса (при наличии);
```
{
  "id": @,
  "userName": "string",
  "password": "string"
}
```
5. Статус-код ответа; 400
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-c2266aa0d39bfb4baf9eb36dff0607c2-8e1f276b9606ca46-00",
  "errors": {
    "$.id": [
      "'@' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 8."
    ]
  }
}
```
### 8. 
1. HTTP-метод; DELETE {id}
2. Полный URL запроса; https://fakerestapi.azurewebsites.net/api/v1/Users/1
3. Заголовки запроса;
```
{
  "accept: */*"
}
```
4. Тело запроса (при наличии);
```
```
5. Статус-код ответа; 200
6. Тело ответа (при наличии). Если тело большое, то только его часть.
```
```


