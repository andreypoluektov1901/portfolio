# Request and Response
# Activities

##  GET 3. Получение полного списка активностей

- **URL запроса:** {{url/api/v1/}}/{{Activities}}

- **Ожидаемый результат:** Статус код ответа 200 ОК, получен полный список активностей.

- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
нет

- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 10 Aug 2024 12:21:37 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0


- **Тело ответа (Response Body):**

```json
 [
    {
        "id": 1,
        "title": "Activity 1",
        "dueDate": "2024-08-10T13:21:38.1057458+00:00",
        "completed": false
    },
    {
        "id": 2,
        "title": "Activity 2",
        "dueDate": "2024-08-10T14:21:38.105748+00:00",
        "completed": true
    }, 
    .......
    {
        "id": 30,
        "title": "Activity 30",
        "dueDate": "2024-08-11T18:21:38.1057586+00:00",
        "completed": true
    }
]
 ```

----


##  POST 8. Добавление новой активности с ID 35

- **URL запроса:** {{url/api/v1/}}/{{Activities}}

- **Ожидаемый результат:** Статус код ответа 200. Успешное добавление новой активности с ID 35

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": 35,
"title": "string",
"dueDate": "2024-08-07T11:52:31.673Z",
"completed": true
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 10 Aug 2024 13:18:21 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
 
- **Тело ответа (Response Body):**

```json
{
    "id": 35,
    "title": "string",
    "dueDate": "2024-08-07T11:52:31.673Z",
    "completed": true
}
```
__________

##  POST 9. Добавление новой активности с ID 3

- **URL запроса:** {{url/api/v1/}}/{{Activities}}

- **Ожидаемый результат:** Статус код ответа 409 (Conflict), сообщение об ошибке при попытке добавить активность с существующим ID 3.

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": 3,
"title": "string",
"dueDate": "2024-08-07T11:52:31.673Z",
"completed": true
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 10 Aug 2024 13:18:21 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
 
- **Тело ответа (Response Body):**

```json
{
  "statusCode": 409,
  "timestamp": "2024-08-07T11:52:31.673Z",
  "path": "v1/Activities",
  "message": "id_3_ALREADY_EXISTS"
}
```
__________


##  POST 10. Добавление новой активности с пустыми строками запроса

- **URL запроса:** {{url/api/v1/}}/{{Activities}}

- **Ожидаемый результат:** Статус код ответа 400, сообщение об ошибке при попытке добавить активность с пустыми строками запроса.

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": ,
"title": ,
"dueDate": ,
"completed":
}
```
- **Заголовки ответа (Response Headers):**
Content-type: application/problem+json; charset=utf-8
Date: Sat, 10 Aug 2024 13:39:26 GMT
Server: Kestrel
Transfer-encoding: chunked
 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-b06540501071104f9254d0c6530ff935-113c5cf623547448-00",
    "errors": {
        "$.id": [
            "',' is an invalid start of a value. Path: $.id | LineNumber: 2 | BytePositionInLine: 6."
        ]
    }
}
```
__________

##  POST 11. Добавление новой активности с dueDate - 0

- **URL запроса:** {{url/api/v1/}}/{{Activities}}

- **Ожидаемый результат:** Статус код ответа 400, сообщение об ошибке при попытке добавить активность с dueDate - 0.

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": 45,
"title": "string",
"dueDate": "0",
"completed": true
}
```
- **Заголовки ответа (Response Headers):**
Content-type: application/problem+json; charset=utf-8
Date: Sat, 10 Aug 2024 13:47:46 GMT
Server: Kestrel
Transfer-encoding: chunked
 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-57acf7920d21334198bbd369eb818e66-a17aafbe64285a48-00",
    "errors": {
        "$.dueDate": [
            "The JSON value could not be converted to System.DateTime. Path: $.dueDate | LineNumber: 6 | BytePositionInLine: 14."
        ]
    }
}
```
__________


##  GET 12. Получение информации об активности с id 2

- **URL запроса:** {{url/api/v1/}}/{{Activities}}/2

- **Ожидаемый результат:** Статус код ответа 200 ОК, получена информация об активности с id 2.

- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
нет

- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 10 Aug 2024 13:52:09 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0


- **Тело ответа (Response Body):**

```json
{
    "id": 2,
    "title": "Activity 2",
    "dueDate": "2024-08-10T15:52:09.9044007+00:00",
    "completed": true
}
 ```

----

##  GET 13. Получение информации об активности с id 0

- **URL запроса:** {{url/api/v1/}}/{{Activities}}/0

- **Ожидаемый результат:** Статус код ответа 404,сообщение об ошибке при попытке получить информацию об активности с id 0, такой активности не существует.
- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
нет

- **Заголовки ответа (Response Headers):**
Content-Type: application/problem+json; charset=utf-8; v=1.0
Date: Sat, 10 Aug 2024 14:18:27 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0


- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
    "title": "Not Found",
    "status": 404,
    "traceId": "00-6d71f0eed4124a4d9d758be116ad13e6-73b90dd6afc55b44-00"
}
 ```

----

##  PUT 14. Изменение информации об активности с валидным id 2

- **URL запроса:** {{url/api/v1/}}/{{Activities}}/2

- **Ожидаемый результат:** Статус код ответа 200, изменения внесены.
- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
```json
{
"id": 55,
"title": "string",
"dueDate": "2024-08-07T11:52:31.673Z",
"completed": true
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 10 Aug 2024 14:22:16 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0


- **Тело ответа (Response Body):**

```json
{
    "id": 55,
    "title": "string",
    "dueDate": "2024-08-07T11:52:31.673Z",
    "completed": true
}
 ```

----


##  PUT 15. Изменение информации на активность c пустыми строками запроса

- **URL запроса:** {{url/api/v1/}}/{{Activities}}/2

- **Ожидаемый результат:** Статус код ответа 400, сообщение об ошибке при попытке изменить информацию на активность с пустыми строками запроса.

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": ,
"title": ,
"dueDate": ,
"completed":
}
```
- **Заголовки ответа (Response Headers):**
Content-type: application/problem+json; charset=utf-8
Date: Sat, 10 Aug 2024 14:50:12 GMT
Server: Kestrel
Transfer-encoding: chunked
 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-1067d03cada66f41b39e590e432f180f-30090ad2a959104e-00",
    "errors": {
        "$.id": [
            "',' is an invalid start of a value. Path: $.id | LineNumber: 2 | BytePositionInLine: 6."
        ]
    }
}
```
__________


##  PUT 16. Изменение информации об активности с id 0

- **URL запроса:** {{url/api/v1/}}/{{Activities}}/0

- **Ожидаемый результат:** Статус код ответа 404, сообщение об ошибке при попытке изменить информацию об активности с id 0, такой активности не существует.

- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": 100,
"title": "string",
"dueDate": "2024-08-07T13:25:06.075Z",
"completed": true
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/problem+json; charset=utf-8; v=1.0
Date: Sat, 10 Aug 2024 14:58:27 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
    "title": "Not Found",
    "status": 404,
    "traceId": "00-6d71f0eed4124a4d9d758be116ad13e6-73b90dd6afc55b44-00"
}
 ```
__________


##  PUT 17. Изменение информации на активность, где dueDate - 0

- **URL запроса:** {{url/api/v1/}}/{{Activities}}/10

- **Ожидаемый результат:** Статус код ответа 400, сообщение об ошибке при попытке изменить информацию на активность с dueDate - 0.

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": 50,
"title": "string",
"dueDate": "0",
"completed": true
}
```
- **Заголовки ответа (Response Headers):**
Content-type: application/problem+json; charset=utf-8
Date: Sat, 10 Aug 2024 15:02:46 GMT
Server: Kestrel
Transfer-encoding: chunked
 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-f9932434e264ad4a95f4a46599473c5b-00aa18614665c64d-00",
    "errors": {
        "$.dueDate": [
            "The JSON value could not be converted to System.DateTime. Path: $.dueDate | LineNumber: 6 | BytePositionInLine: 14."
        ]
    }
}
```
__________

##  DELETE 19. Удаление активности с валидным id 2

- **URL запроса:** {{url/api/v1/}}/{{Activities}}/2

- **Ожидаемый результат:** Статус код ответа 200, активность с id 2 удалена.
- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
нет

- **Заголовки ответа (Response Headers):**
Content-Length: 0
Date: Sat, 10 Aug 2024 15:06:27 GMT
Server: Kestrel
api-supported-versions: 1.0


- **Тело ответа (Response Body):**
нет

----
# Authors

## GET 6. Получение полного списка авторов

- **URL запроса:** {{url/api/v1/}}/{{Authors}}

- **Ожидаемый результат:** Статус код ответа 200 ОК, получен списока авторов.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
нет

- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
        "id": 1,
        "idBook": 1,
        "firstName": "First Name 1",
        "lastName": "Last Name 1"
    },
    {
        "id": 2,
        "idBook": 1,
        "firstName": "First Name 2",
        "lastName": "Last Name 2"
    },
    {
        "id": 3,
        "idBook": 2,
        "firstName": "First Name 3",
        "lastName": "Last Name 3"
    }, ...
```
----
## POST 18. Добавление нового автора id 700
- **URL запроса:**{{url/api/v1/}}/{{Authors}}

- **Ожидаемый результат:** Статус код ответа 200 ОК, Добавлен новый автор.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 700,
"idBook": 0,
"firstName": "string",
"lastName": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
    "id": 700,
    "idBook": 0,
    "firstName": "string",
    "lastName": "string"
}
```
-----
## POST 20. Добавление нового автора id 3

- **URL запроса:** {{url/api/v1/}}/{{Authors}}

- **Ожидаемый результат:** Статус код ответа 409 {Conflict}.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 3,
"idBook": 0,
"firstName": "string",
"lastName": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "statusCode": 409,
  "timestamp": "2024-08-07T11:52:31.673Z",
  "path": "v1/Authors",
  "message": "id_3_ALREADY_EXISTS"
}
```
-----
## POST 56. Добавление нового автора с idBook 700

- **URL запроса:** {{url/api/v1/}}/{{Authors}}

- **Ожидаемый результат:** Статус код ответа 200, Добавлен новый автор.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 0,
"idBook": 700,
"firstName": "string",
"lastName": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
    "id": 0,
    "idBook": 700,
    "firstName": "string",
    "lastName": "string"
}
```
----
## POST 55. Добавление нового автора с idBook 3

- **URL запроса:** {{url/api/v1/}}/{{Authors}}

- **Ожидаемый результат:** Статус код ответа 409 {Conflict}.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 0,
"idBook": 3,
"firstName": "string",
"lastName": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "statusCode": 409,
  "timestamp": "2024-08-07T11:52:31.673Z",
  "path": "v1/Authors",
  "message": "id_3_ALREADY_EXISTS"
}
```
----
## POST 21. Добавление нового автора с пустыми строками запроса

- **URL запроса:** {{url/api/v1/}}/{{Authors}}

- **Ожидаемый результат:** Статус код ответа 400.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": ,
"idBook": ,
"firstName": ,
"lastName":
}
```
- **Заголовки ответа (Response Headers):**
CContent-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-43dca410ac789642b0f053ea1fa87f15-984766765848714b-00",
  "errors": {
    "$.id": [
      "',' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 8."
    ]
  }
}
```
-----
## POST 22. Добавление нового автора с firstName 0

- **URL запроса:**  {{url/api/v1/}}/{{Authors}}

- **Ожидаемый результат:** Статус код ответа 400.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 700,
"idBook": 700,
"firstName": "0",
"lastName": "0"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-ad53c2ecfcb00b499de6c38d85feeed6-f7b6ad42636ff246-00",
  "errors": {
    "$.id": [
      "The JSON value could not be converted to System.Int32. Path: $.id | LineNumber: 0 | BytePositionInLine: 10."
    ]
  }
}
```
-----
## GET 23. Получение информации об авторе с idBook 2

- **URL запроса:**  {{url/api/v1/}}/{{Authors}}

- **Ожидаемый результат:** Статус код ответа 200. Получена информация об авторе idBook {2}

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
Отсутствует
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
[
  {
    "id": 4,
    "idBook": 2,
    "firstName": "First Name 4",
    "lastName": "Last Name 4"
  },
  {
    "id": 5,
    "idBook": 2,
    "firstName": "First Name 5",
    "lastName": "Last Name 5"
  }
]
```

-----
## GET 24. Получение информации об авторе с idBook 0

- **URL запроса:** {{url/api/v1/}}/{{Authors}}

- **Ожидаемый результат:** Статус код ответа 404.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
Отсутствует
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
  "title": "Not Found",
  "status": 404,
  "traceId": "00-72198ba31368fd4184c5670b8eca2ace-d316b04871a5094b-00"
}
```
___
## GET 25. Получение информации об авторе с id 2

- **URL запроса:**  {{url/api/v1/}}/{{Authors}}/2

- **Ожидаемый результат:** Статус код ответа 2, Получена информация об авторе id {2}

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
Отсутствует
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "id": 2,
  "idBook": 1,
  "firstName": "First Name 2",
  "lastName": "Last Name 2"
}
```
-----

## GET 26. Получение информации об авторе с id 0

- **URL запроса:**  {{url/api/v1/}}/{{Authors}}

- **Ожидаемый результат:** Статус код ответа 404.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
Отсутствует
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
  "title": "Not Found",
  "status": 404,
  "traceId": "00-72198ba31368fd4184c5670b8eca2ace-d316b04871a5094b-00"
}
```
-----

## PUT 27. Изменение информации об авторе с валидным id

- **URL запроса:**  {{url/api/v1/}}/{{Authors}}/2

- **Ожидаемый результат:** Статус код ответа 200, информация об авторе успешно изменена.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
Content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 55,
"idBook": 0,
"firstName": "string",
"lastName": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "id": 55,
  "idBook": 0,
  "firstName": "string",
  "lastName": "string"
}
```
-----
## PUT 28. Изменение информации об авторе с валидным id, на id c пустыми строками запроса

- **URL запроса:** {{url/api/v1/}}/{{Authors}}/2

- **Ожидаемый результат:** Статус код ответа 400.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
Content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": ,
"idBook": ,
"firstName": ,
"lastName":
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-192fb55b71628b4b9b8e70cdcc42291f-e04f45a55d5f0143-00",
  "errors": {
    "$.id": [
      "',' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 8."
    ]
  }
}
```
-----
## PUT 29. изменение информации об авторе с id 0

- **URL запроса:** {{url/api/v1/}}/{{Authors}}

- **Ожидаемый результат:** Статус код ответа 404.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
Content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 0,
"idBook": 10,
"firstName": "string",
"lastName": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
 "type":"https://tools.ietf.org/html/rfc7231#section-6.5.4", 
"title": "Not Found", 
"status": 404, 
"traceId": "00-cc6352395bf7804392fa7a7dbb5a3c5b-b4489dd9b052824e-00" 
}
```
----
## PUT 30. изменение информации об авторе, где firstName {}, lastName{}

- **URL запроса:**  {{url/api/v1/}}/{{Authors}}

- **Ожидаемый результат:** Статус код ответа 200.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
Content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 1,
"idBook": 1,
"firstName": "",
"lastName": ""
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
"id": 1,
"idBook": 1,
"firstName": "",
"lastName": ""
}
```
-----
## DELETE 31. удаление автора с валидным id 2

- **URL запроса:**  {{url/api/v1/}}/{{Authors}}/2

- **Ожидаемый результат:** Статус код ответа 200, автор успешно удалён.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
Отсутствует.
- **Заголовки ответа (Response Headers):**
Content-Length: 0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
Отсутствует
---


# Books


##  GET 43. Получение полного списка книг

- **URL запроса:** {{url/api/v1/}}/{{Books}}

- **Ожидаемый результат:** Статус код ответа 200 ОК, получен полный список книг.

- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
нет

- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 12 Aug 2024 18:32:00 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0


- **Тело ответа (Response Body):**

```json
 [
    {
        "id": 1,
        "title": "Book 1",
        "description": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
        "pageCount": 100,
        "excerpt": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
        "publishDate": "2024-08-11T18:32:01.3834933+00:00"
    },
    .......
    {
        "id": 200,
        "title": "Book 200",
        "description": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
        "pageCount": 20000,
        "excerpt": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
        "publishDate": "2024-01-25T18:32:01.3886168+00:00"
    }
]
 ```

----


##  POST 79. Добавление новой книги с ID 201

- **URL запроса:** {{url/api/v1/}}/{{Books}}

- **Ожидаемый результат:** Статус код ответа 200. Успешное добавление новой книги с ID 201

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": 201,
"title": "string",
"description": "string",
"pageCount": 0,
"excerpt": "string",
"publishDate": "2024-08-10T19:13:56.060Z"
}
```
- **Заголовки ответа (Response Headers):**

Content-Type: application/json; charset=utf-8; v=1.0
Date: Mon, 12 Aug 2024 18:42:28 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
 
- **Тело ответа (Response Body):**

```json
{
"id":201,
"title": "string",
"description": "string",
"pageCount": 0,
"excerpt": "string",
"publishDate": "2024-08-07T19:01:33.977Z"
}
```
__________

##  POST 47. Books/POST: добавление новой книги с ID-77777777777

- **URL запроса:** {{url/api/v1/}}/{{Books}}

- **Ожидаемый результат:** Статус код ответа 400, сообщение об ошибке при попытке добавить книгу с очень большим номером ID.

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Cache-Control: no-cache

- **Тело запроса (Request Body)**
```json
{
"id":77777777777,
"title": "string",
"description": "string",
"pageCount": 0,
"excerpt": "string",
"publishDate": "2024-08-07T19:01:33.977Z"
}
```
- **Заголовки ответа (Response Headers):**

Content-Type: application/problem+json; charset=utf-8
Date: Mon, 12 Aug 2024 18:45:04 GMT
Server: Kestrel
Transfer-Encoding: chunked

 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-42c348b97b309f4fb119076ed4201157-d5798ca064b3ae47-00",
    "errors": {
        "$.id": [
            "The JSON value could not be converted to System.Int32. Path: $.id | LineNumber: 2 | BytePositionInLine: 16."
        ]
    }
}
```
__________


##  POST 48. Добавление новой книги с пустыми строками запроса

- **URL запроса:** {{url/api/v1/}}/{{Books}}

- **Ожидаемый результат:** Статус код ответа 400, сообщение об ошибке при попытке добавить книгу с пустыми строками запроса.

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id":,
"title": ,
"description": ,
"pageCount": ,
"excerpt": ,
"publishDate":
}
```
- **Заголовки ответа (Response Headers):**
Content-type: application/problem+json; charset=utf-8
Date: Mon, 12 Aug 2024 18:51:46 GMT
Server: Kestrel
Transfer-encoding: chunked
 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-6cc4ac2d2f31a14cb9429cdebc2b6db7-79f78bc51a357b46-00",
    "errors": {
        "$.id": [
            "',' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 5."
        ]
    }
}
```
__________

##  POST 44. Добавление новой книги с ID 7

- **URL запроса:** {{url/api/v1/}}/{{Books}}

- **Ожидаемый результат:** Статус код ответа 409 (Conflict), сообщение об ошибке при попытке добавить книгу с существующим ID 7.

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": 7,
"title": "string",
"description": "string",
"pageCount": 0,
"excerpt": "string",
"publishDate": "2024-08-10T19:13:56.060Z"
}
```
- **Заголовки ответа (Response Headers):**
Content-type: application/problem+json; charset=utf-8
Date: Mon, 12 Aug 2024 18:56:42 GMT
Server: Kestrel
Transfer-encoding: chunked
 
- **Тело ответа (Response Body):**

```json
{
  "statusCode": 409,
  "timestamp": "2024-08-07T11:52:31.673Z",
  "path": "v1/Books",
  "message": "id_7_ALREADY_EXISTS"
}
```
__________


##  GET 49. Получение информации о книге с id 7

- **URL запроса:** {{url/api/v1/}}/{{Books}}/7

- **Ожидаемый результат:** Статус код ответа 200 ОК, получена информация о книге с id 7.

- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
нет

- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Mon, 12 Aug 2024 19:06:40 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0


- **Тело ответа (Response Body):**
```json
{
    "id": 7,
    "title": "Book 7",
    "description": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
    "pageCount": 700,
    "excerpt": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
    "publishDate": "2024-08-05T19:06:41.1190836+00:00"
}
 ```

----

##  GET 50. Получение информации о книге с id 777

- **URL запроса:** {{url/api/v1/}}/{{Books}}/777

- **Ожидаемый результат:** Статус код ответа 404,сообщение об ошибке при попытке получить информацию о книге с id 777, такой книги не существует.
- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
нет

- **Заголовки ответа (Response Headers):**
Content-Type: application/problem+json; charset=utf-8; v=1.0
Date: Mon, 12 Aug 2024 19:08:50 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0


- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
    "title": "Not Found",
    "status": 404,
    "traceId": "00-9199c47eb68f644789559e524c20f252-77e7f6a3561c6343-00"
}
 ```

----

##  PUT 51. Изменение информации о книге с валидным id 7

- **URL запроса:** {{url/api/v1/}}/{{Books}}/7

- **Ожидаемый результат:** Статус код ответа 200, изменения внесены.
- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
```json
{
"id": 0,
"title": "string",
"description": "string",
"pageCount": 0,
"excerpt": "string",
"publishDate": "2024-08-07T19:52:55.480Z"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Mon, 12 Aug 2024 19:09:43 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0


- **Тело ответа (Response Body):**

```json
{
"id": 0,
"title": "string",
"description": "string",
"pageCount": 0,
"excerpt": "string",
"publishDate": "2024-08-07T19:52:55.480Z"
}
 ```

----


##  PUT 52. Изменение информации о книге c пустыми строками запроса

- **URL запроса:** {{url/api/v1/}}/{{Books}}/7

- **Ожидаемый результат:** Статус код ответа 400, сообщение об ошибке при попытке изменить информацию о книге с пустыми строками запроса.

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id":,
"title": ,
"description": ,
"pageCount": ,
"excerpt": ,
"publishDate":
}
```
- **Заголовки ответа (Response Headers):**
Content-type: application/problem+json; charset=utf-8
Date: Mon, 12 Aug 2024 19:13:02 GMT
Server: Kestrel
Transfer-encoding: chunked
 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-2b7b0b80c679d045b8180fceec1c30fa-c27593d2f6f17643-00",
    "errors": {
        "$": [
            "',' is invalid after a property name. Expected a ':'. Path: $ | LineNumber: 2 | BytePositionInLine: 4."
        ]
    }
}
```
__________


##  PUT 53. Изменение информации о книге с id 0

- **URL запроса:** {{url/api/v1/}}/{{Books}}/0

- **Ожидаемый результат:** Статус код ответа 404, сообщение об ошибке при попытке изменить информацию книге с id 0, такой книги не существует.

- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Type: application/json

- **Тело запроса (Request Body)**
```json
{
"id": 230,
"title": "string",
"description": "string",
"pageCount": 0,
"excerpt": "string",
"publishDate": "2024-08-09T17:59:29.983Z"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/problem+json; charset=utf-8; v=1.0
Date: Mon, 12 Aug 2024 19:19:42 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
    "title": "Not Found",
    "status": 404,
    "traceId": "00-6d71f0eed4124a4d9d758be116ad13e6-73b90dd6afc55b44-00"
}
 ```
__________


##  PUT 76. Изменение информации о книге с пустым значением publishDate

- **URL запроса:** {{url/api/v1/}}/{{Books}}/7

- **Ожидаемый результат:** Статус код ответа 400, сообщение об ошибке при попытке изменить информацию о книге с пустым значением publishDate

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": 0,
"title": "string",
"description": "string",
"pageCount": 0,
"excerpt": "string",
"publishDate":
}
```
- **Заголовки ответа (Response Headers):**
Content-type: application/problem+json; charset=utf-8
Date: Mon, 12 Aug 2024 19:23:39 GMT
Server: Kestrel
Transfer-encoding: chunked
 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-1662d335bc5064439cecbecbe50798bd-adb17c9a2b30784f-00",
    "errors": {
        "$.publishDate": [
            "'}' is an invalid start of a value. Path: $.publishDate | LineNumber: 7 | BytePositionInLine: 0."
        ]
    }
}
```
__________

##  DELETE 54. Удаление книги с валидным id 7

- **URL запроса:** {{url/api/v1/}}/{{Books}}/7

- **Ожидаемый результат:** Статус код ответа 200, книга с id 7 удалена.
- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
нет

- **Заголовки ответа (Response Headers):**
Content-Length: 0
Date: Mon, 12 Aug 2024 19:25:32 GMT
Server: Kestrel
api-supported-versions: 1.0


- **Тело ответа (Response Body):**
нет

----

# CoverPhotos

## GET 57.Получение полного списка фотографий обложек

- **URL запроса:**{{url/api/v1/}}/{{CoverPhotos}}

- **Ожидаемый результат:** Статус код ответа 200 ОК, получен списока фотографий обложек.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
нет

- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0

- **Тело ответа(Response Body):**
```
[
  {
    "id": 1,
    "idBook": 1,
    "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 1&w=250&h=350"
  },
  {
    "id": 2,
    "idBook": 2,
    "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 2&w=250&h=350"
  },
  {
    "id": 3,
    "idBook": 3,
    "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 3&w=250&h=350"
  }, ...
]
```
----
## POST 58. Добавление новой фотографии обложки id 201

- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}

- **Ожидаемый результат:** Статус код ответа 200 ОК, Добавлена новая фотография обложки.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 201,
"idBook": 0,
"url": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа(Response Body):**
```
{
  "id": 201,
  "idBook": 0,
  "url": "string"
}
```
-----
## POST 59. Добавление новой фотографии обложки с id 3

- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}

- **Ожидаемый результат:** Статус код ответа 409 {Conflict}.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 3,
"idBook": 3,
"url": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "statusCode": 409,
  "timestamp": "2024-08-07T11:52:31.673Z",
  "path": "v1/CoverPhotos",
  "message": "id_3_ALREADY_EXISTS"
}
```
----

## POST 60. Добавление новой фотографии обложки с idBook 201

- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}

- **Ожидаемый результат:** Статус код ответа 200, Добавлена новая фотография обложки.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
  "id": 0,
  "idBook": 201,
  "url": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа(Response Body):**
```
{
    "id": 0,
    "idBook": 700,
    "firstName": "string",
    "lastName": "string"
}
```
----
## POST 61. Добавление новой фотографии обложки с idBook 3

- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}

- **Ожидаемый результат:** Статус код ответа 409 {Conflict}.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 3,
"idBook": 3,
"url": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа(Response Body):**
```
{
  "statusCode": 409,
  "timestamp": "2024-08-07T11:52:31.673Z",
  "path": "v1/CoverPhotos",
  "message": "id_3_ALREADY_EXISTS"
}
```
----

## POST 62. Добавление новой фотографии обложки с пустыми строками запроса

- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}

- **Ожидаемый результат:** Статус код ответа 400.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": ,
"idBook": ,
"url": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-43dca410ac789642b0f053ea1fa87f15-984766765848714b-00",
  "errors": {
    "$.id": [
      "',' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 8."
    ]
  }
}
```
---
## POST 63. Добавление новой фотографии обложки с url: 0

- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}

- **Ожидаемый результат:** Статус код ответа 400.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 201,
"idBook": 201,
"url": 0
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа(Response Body):**
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-ad53c2ecfcb00b499de6c38d85feeed6-f7b6ad42636ff246-00",
  "errors": {
    "$.id": [
      "The JSON value could not be converted to System.Int32. Path: $.id | LineNumber: 0 | BytePositionInLine: 10."
    ]
  }
}
```
----
## GET 64. Получение информации об обложке с idBoock 2

- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}

- **Ожидаемый результат:** Статус код ответа 200. Получена информация об фотографии обложки idBook {2}

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
Отсутствует
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа(Response Body):**
```
[
  {
    "id": 2,
    "idBook": 2,
    "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 2&w=250&h=350"
  }
]
```
----
## GET 65. получение информации об фотографии обложки с idBook 0

- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}

- **Ожидаемый результат:** Статус код ответа 404.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
Отсутствует
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа(Response Body):**
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
  "title": "Not Found",
  "status": 404,
  "traceId": "00-72198ba31368fd4184c5670b8eca2ace-d316b04871a5094b-00"
}
```
----
## GET 66. Пполучение информации об фотографии обложки с id 2

- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}/2

- **Ожидаемый результат:** Статус код ответа 2, Получена информация об фотографии обложки id {2}

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
Отсутствует
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "id": 2,
  "idBook": 2,
  "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 2&w=250&h=350"
}
```
-----

## GET 67. Пполучение информации об фотографии обложки с id 0
- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}/0

- **Ожидаемый результат:** Статус код ответа 404.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
Отсутствует
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
  "title": "Not Found",
  "status": 404,
  "traceId": "00-72198ba31368fd4184c5670b8eca2ace-d316b04871a5094b-00"
}
```
----
## PUT 68. Изменение информации об фотографии обложки с валидным id 

- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}/3

- **Ожидаемый результат:** Статус код ответа 200, информация об фотографии обложки успешно изменена.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
Content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 3,
"idBook": 3,
"url": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "id": 3,
  "idBook": 3,
  "url": "string"
}
```
----
## PUT 69. изменение информации об фотографии обложки с валидным id, на id c пустыми строками запроса

- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}/2

- **Ожидаемый результат:** Статус код ответа 400.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
Content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": ,
"idBook": ,
"url": ""
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-192fb55b71628b4b9b8e70cdcc42291f-e04f45a55d5f0143-00",
  "errors": {
    "$.id": [
      "',' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 8."
    ]
  }
}
```
----
## PUT 70.изменение информации об фотографии обложки с id 0

- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}/0

- **Ожидаемый результат:** Статус код ответа 404.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
Content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 1,
"idBook": 1,
"url": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
 "type":"https://tools.ietf.org/html/rfc7231#section-6.5.4", 
"title": "Not Found", 
"status": 404, 
"traceId": "00-cc6352395bf7804392fa7a7dbb5a3c5b-b4489dd9b052824e-00" 
}
```
-----
## PUT 71. изменение информации об фотографии обложки, где  url: {}

- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}/10

- **Ожидаемый результат:** Статус код ответа 200.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
Content-Type: application/json
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
```
{
"id": 1,
"idBook": 1,
"url": ""
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
```
{
"id": 1,
"idBook": 1,
"url": ""
}
```
----
## DELETE 72. удаление фотографии обложки с валидным id 2

- **URL запроса:** {{url/api/v1/}}/{{CoverPhotos}}/2

- **Ожидаемый результат:** Статус код ответа 200, фотография обложки успешно удалена.

- **Заголовки запроса (Request Headers):**
Cache-Control: no-cache
User-Agent: PostmanRuntime/7.40.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
- **Тело запроса**
Отсутствует.
- **Заголовки ответа (Response Headers):**
Content-Length: 0
Date: Wed, Sat, 10 aug 2024 13:55:57 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
- **Тело ответа (Response Body):**
Отсутствует
___
# Users
##  GET 32. Получение полного списка пользователей

- **URL запроса:** {{url/api/v1/}}/{{Users}}

- **Ожидаемый результат:** Статус код ответа 200 ОК, получен полный список пользователей.

- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
нет

- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 10 Aug 2024 15:22:37 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0


- **Тело ответа (Response Body):**

```json
 [
    {
        "id": 1,
        "userName": "User 1",
        "password": "Password1"
    },
    {
        "id": 2,
        "userName": "User 2",
        "password": "Password2"
    },
    .......
    {
        "id": 10,
        "userName": "User 10",
        "password": "Password10"
    }
]
 ```

----
##  POST 34. Добавление нового пользователя с ID 11

- **URL запроса:** {{url/api/v1/}}/{{Users}}

- **Ожидаемый результат:** Статус код ответа 200. Успешное добавление нового пользователя с ID 11

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": 11,
"userName": "string",
"password": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 10 Aug 2024 15:33:21 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
 
- **Тело ответа (Response Body):**

```json
{
"id": 11,
"userName": "string",
"password": "string"
}
```
__________

##  POST 35. Добавление нового пользователя с ID 5

- **URL запроса:** {{url/api/v1/}}/{{Users}}

- **Ожидаемый результат:** Статус код ответа 409 (Conflict), сообщение об ошибке при попытке добавить пользователя с существующим ID 5.

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": 5,
"userName": "string",
"password": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 10 Aug 2024 15:18:21 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
 
- **Тело ответа (Response Body):**

```json
{
  "statusCode": 409,
  "timestamp": "2024-08-07T11:52:31.673Z",
  "path": "v1/Users",
  "message": "id_5_ALREADY_EXISTS"
}
```
__________


##  POST 36. Добавление нового пользователя с пустыми строками запроса

- **URL запроса:** {{url/api/v1/}}/{{Users}}

- **Ожидаемый результат:** Статус код ответа 400, сообщение об ошибке при попытке добавить пользователя с пустыми строками запроса.

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": ,
"userName": ,
"password":
}
```
- **Заголовки ответа (Response Headers):**
Content-type: application/problem+json; charset=utf-8
Date: Sat, 10 Aug 2024 15:42:26 GMT
Server: Kestrel
Transfer-encoding: chunked
 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-b06540501071104f9254d0c6530ff935-113c5cf623547448-00",
    "errors": {
        "$.id": [
            "',' is an invalid start of a value. Path: $.id | LineNumber: 2 | BytePositionInLine: 6."
        ]
    }
}
```
__________

##  POST 37. Добавление нового пользователя с именем - 0

- **URL запроса:** {{url/api/v1/}}/{{Users}}

- **Ожидаемый результат:** Статус код ответа 400, сообщение об ошибке при попытке добавить нового пользователя с userName - 0.

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": 15,
"userName": 0,
"password": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-type: application/problem+json; charset=utf-8
Date: Sat, 10 Aug 2024 16:10:46 GMT
Server: Kestrel
Transfer-encoding: chunked
 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-1ab42518d7e56b4d833076e535e5dd22-b20276abe15d2b4d-00",
    "errors": {
        "$.userName": [
            "The JSON value could not be converted to System.String. Path: $.userName | LineNumber: 2 | BytePositionInLine: 13."
        ]
    }
}
```
__________

##  GET 39. Получение информации о пользователе с id 1

- **URL запроса:** {{url/api/v1/}}/{{Users}}/1

- **Ожидаемый результат:** Статус код ответа 200 ОК, получена информация о пользователе с id 1.

- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
нет

- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 10 Aug 2024 16:20:09 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0


- **Тело ответа (Response Body):**

```json
{
    "id": 1,
    "userName": "User 1",
    "password": "Password1"
}
 ```

----

##  GET 38. Получение информации о пользователе с id 0

- **URL запроса:** {{url/api/v1/}}/{{Users}}/0

- **Ожидаемый результат:** Статус код ответа 404, сообщение об ошибке при попытке получить информацию о пользователе с id 0, такого пользователя не существует.
- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
нет

- **Заголовки ответа (Response Headers):**
Content-Type: application/problem+json; charset=utf-8; v=1.0
Date: Sat, 10 Aug 2024 16:15:27 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0


- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
    "title": "Not Found",
    "status": 404,
    "traceId": "00-d82c0aa255d712468096672efa3fac5b-a7a90795d9f6584a-00"
}
 ```

----

##  PUT 40. Изменение информации о пользователе с валидным id 3

- **URL запроса:** {{url/api/v1/}}/{{Users}}/3

- **Ожидаемый результат:** Статус код ответа 200, изменения внесены.
- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
```json
{
  "id": 15,
  "userName": "string",
  "password": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 10 Aug 2024 16:30:16 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0


- **Тело ответа (Response Body):**

```json
{
  "id": 15,
  "userName": "string",
  "password": "string"
}
 ```

----


##  PUT 41. Изменение информации на пользователя c пустыми строками запроса

- **URL запроса:** {{url/api/v1/}}/{{Users}}/3

- **Ожидаемый результат:** Статус код ответа 400, сообщение об ошибке при попытке изменить информацию на  пользователя с пустыми строками запроса.

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": ,
"userName": ,
"password":
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 10 Aug 2024 16:33:04 GMT
Server: Kestrel
Transfer-encoding: chunked
 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-1fbbae36c5d48047b28c1714f84b649a-229a26dacd651440-00",
    "errors": {
        "$.id": [
            "',' is an invalid start of a value. Path: $.id | LineNumber: 1 | BytePositionInLine: 6."
        ]
    }
}
```
__________


##  PUT 42. Изменение информации на пользователя с именем - 0
- **URL запроса:** {{url/api/v1/}}/{{Users}}/3

- **Ожидаемый результат:** Статус код ответа 400, сообщение об ошибке при попытке изменить информацию на пользователя с именем 0.

- **Заголовки запроса (Request Headers):**
Content-Type: application/json
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": 15,
"userName": 0,
"password": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-type: application/problem+json; charset=utf-8
Date: Sat, 10 Aug 2024 16:40:34 GMT
Server: Kestrel
Transfer-encoding: chunked
 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-4b0cc899e201b840b67b8213be7769e3-a8b787402a971348-00",
    "errors": {
        "$.userName": [
            "The JSON value could not be converted to System.String. Path: $.userName | LineNumber: 2 | BytePositionInLine: 13."
        ]
    }
}
 ```
__________


##  PUT 45. Изменение информации пользователя с id 0

- **URL запроса:** {{url/api/v1/}}/{{Users}}/0

- **Ожидаемый результат:** Статус код ответа 404, сообщение об ошибке при попытке изменить информацию о пользователе с id 0, такого пользователя не существует.

- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса (Request Body)**
```json
{
"id": 32,
"userName": "string",
"password": "string"
}
```
- **Заголовки ответа (Response Headers):**
Content-Type: application/problem+json; charset=utf-8; v=1.0
Date: Sat, 10 Aug 2024 14:58:27 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
 
- **Тело ответа (Response Body):**

```json
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
    "title": "Not Found",
    "status": 404,
    "traceId": "00-6d71f0eed4124a4d9d758be116ad13e6-73b90dd6afc55b44-00"
}
```
__________

##  DELETE 46. Удаление пользователя с валидным id 3

- **URL запроса:** {{url/api/v1/}}/{{Users}}/3

- **Ожидаемый результат:** Статус код ответа 200, пользователь с id 3 удален.
- **Заголовки запроса (Request Headers):**
User-Agent: PostmanRuntime/7.41.0
Accept: */*
Cache-Control: no-cache
Accept-Encoding: gzip, deflate, br
Connection: keep-alive

- **Тело запроса**
нет

- **Заголовки ответа (Response Headers):**
Content-Length: 0
Date: Sat, 10 Aug 2024 17:01:17 GMT
Server: Kestrel
api-supported-versions: 1.0

- **Тело ответа (Response Body):**
нет











































