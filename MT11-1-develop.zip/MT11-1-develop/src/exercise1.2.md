### Тестовое окружение

### Устройство/Браузер версия.

Ссылка на чат: https://rocketchat-todogood.21-school.ru/group/jeltzlog

ПК - Windows 11 Pro, Версия 23H2 x64: 

1. Chrome - Версия 128.0.6613.120 (Официальная сборка), (64 бит).

2. Firefox - версия 130.0 (официальная сборка), (64 бит)

Телефон (Redmi Note 11 Pro) - Android 13 TP1A.220624.014 /  Xiaomi HyperOS 1.0.4.TGDMIXM.

1. Chrome -Версия 128.0.6613.127

2. Firefox - Версия 129.0.2

### Разрешение экрана

ПК: 

- max 2560 x 1440, 
- min 800x600

Телефон 

- 2400 x 1080
