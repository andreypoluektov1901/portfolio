

## Какой запрос(-ы) отправляется на сервер для получения списка типов товаров в шторке "Каталог"?

**POST** <br>
https://megamarket.ru/api/mobile/v1/catalogService/catalog/menu 
## Какой запрос(-ы) отправляется на сервер при использовании поиска товаров в каталоге?

**POST** <br>
https://megamarket.ru/api/mobile/v3/catalogService/catalog/searchSuggest <br>

**POST** <br>
https://megamarket.ru/api/mobile/v1/catalogService/catalog/search <br>

**POST**

https://megamarket.ru/api/mobile/v1/catalogService/filters/search <br>

## Какой запрос(-ы) отправляется на сервер при поиске региона или города в модалке выбора вашего региона?
**POST** <br>
https://megamarket.ru/api/mobile/v1/addressSuggestService/address/suggest <br>


**POST** <br>
https://megamarket.ru/api/mobile/v1/regionService/region/search <br>


